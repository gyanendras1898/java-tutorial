package com.sujata.demo;

public class MyMainClass {

	public static void main(String[] args) {
		Student student=new Student();
		
		student.input(111, "AAAA");
		student.display();
		

	}

}
